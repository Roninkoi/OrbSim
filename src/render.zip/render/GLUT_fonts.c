#include "GL/glut.h"
void *glut_stroke_roman=GLUT_STROKE_ROMAN;
void *glut_stroke_mono_roman=GLUT_STROKE_MONO_ROMAN;
void *glut_bitmap_9_by_15=GLUT_BITMAP_9_BY_15;
void *glut_bitmap_8_by_13=GLUT_BITMAP_8_BY_13;
void *glut_bitmap_times_roman_10=GLUT_BITMAP_TIMES_ROMAN_10;
void *glut_bitmap_times_roman_24=GLUT_BITMAP_TIMES_ROMAN_24;
#if (GLUT_API_VERSION >= 3)
void *glut_bitmap_helvetica_10=GLUT_BITMAP_HELVETICA_10;
void *glut_bitmap_helvetica_12=GLUT_BITMAP_HELVETICA_12;
void *glut_bitmap_helvetica_18=GLUT_BITMAP_HELVETICA_18;
#endif
